import CartPage from "@/app/components/Pages/Cart";

export default function CartRoutePage() {
  return <CartPage />;
}