import AuthLayout from '@/app/components/Pages/Auth/AuthLayout';

export default function LoginPage() {
  return <AuthLayout defaultMode="login" />;
}
