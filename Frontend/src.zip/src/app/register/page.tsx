import AuthLayout from '@/app/components/Pages/Auth/AuthLayout';

export default function RegisterPage() {
  return <AuthLayout defaultMode="register" />;
}
