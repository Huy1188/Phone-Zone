import AccountPage from "../components/Pages/Account";

export default function Page() {
  return <AccountPage />;
}
