export interface DashboardStats {
    userCount: number;
    postCount: number;
    productCount: number;
    orderCount: number;
}
